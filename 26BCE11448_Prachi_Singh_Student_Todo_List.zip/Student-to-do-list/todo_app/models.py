from dataclasses import dataclass, asdict

@dataclass
class Todo:
    id: int
    title: str
    description: str
    due_date: str
    priority: str = "Medium"
    category: str = "General"
    status: str = "Pending"

    def to_dict(self):
        return asdict(self)

    @staticmethod
    def from_dict(data):
        if not isinstance(data, dict):
            raise TypeError("Data must be a dictionary")
        return Todo(
            id=int(data.get("id", 0)),
            title=str(data.get("title", "")),
            description=str(data.get("description", "")),
            due_date=str(data.get("due_date", "")),
            priority=str(data.get("priority", "Medium")),
            category=str(data.get("category", "General")),
            status=str(data.get("status", "Pending")),
        )
