from .models import Todo
from .storage import load_todos, save_todos

class TodoManager:
    def __init__(self, storage_file=None):
        self.storage_file = storage_file
        self.todos = load_todos(self.storage_file)

    def next_id(self):
        return max((t.id for t in self.todos), default=0) + 1

    def add(self, title, description, due_date, priority, category):
        todo = Todo(
            self.next_id(),
            str(title).strip(),
            str(description).strip(),
            str(due_date).strip(),
            str(priority).strip(),
            str(category).strip() or "General"
        )
        self.todos.append(todo)
        save_todos(self.todos, self.storage_file)
        return todo

    def get(self, todo_id):
        for todo in self.todos:
            if todo.id == todo_id:
                return todo
        return None

    def update(self, todo_id, title, description, due_date, priority, category, status):
        for todo in self.todos:
            if todo.id == todo_id:
                todo.title = str(title).strip()
                todo.description = str(description).strip()
                todo.due_date = str(due_date).strip()
                todo.priority = str(priority).strip()
                todo.category = str(category).strip() or "General"
                todo.status = str(status).strip()
                save_todos(self.todos, self.storage_file)
                return True
        return False

    def delete(self, todo_id):
        old_count = len(self.todos)
        self.todos = [t for t in self.todos if t.id != todo_id]
        save_todos(self.todos, self.storage_file)
        return len(self.todos) < old_count

    def complete(self, todo_id):
        for todo in self.todos:
            if todo.id == todo_id:
                todo.status = "Completed"
                save_todos(self.todos, self.storage_file)
                return True
        return False

    def toggle_status(self, todo_id):
        for todo in self.todos:
            if todo.id == todo_id:
                todo.status = "Pending" if todo.status == "Completed" else "Completed"
                save_todos(self.todos, self.storage_file)
                return todo.status
        return None

    def all(self):
        return list(self.todos)

