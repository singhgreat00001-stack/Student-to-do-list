from datetime import datetime

PRIORITIES = {"Low", "Medium", "High"}
STATUSES = {"Pending", "Completed"}

def validate_todo(title, due_date, priority):
    if not title or not str(title).strip():
        return False, "Task title is required."
    if not due_date or not str(due_date).strip():
        return False, "Due date is required."
    try:
        datetime.strptime(str(due_date).strip(), "%Y-%m-%d")
    except (ValueError, TypeError):
        return False, "Due date must use YYYY-MM-DD format."
    if str(priority).strip() not in PRIORITIES:
        return False, "Please select a valid priority."
    return True, ""

def validate_status(status):
    return str(status).strip() in STATUSES