import json
from pathlib import Path
from .models import Todo

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "todos.json"

def load_todos(filepath=None):
    target = Path(filepath) if filepath else DATA_FILE
    if not target.exists():
        return []
    try:
        with open(target, "r", encoding="utf-8") as f:
            data = json.load(f)
            if not isinstance(data, list):
                return []
            return [Todo.from_dict(x) for x in data if isinstance(x, dict)]
    except (OSError, json.JSONDecodeError, TypeError, ValueError, KeyError):
        return []

def save_todos(todos, filepath=None):
    target = Path(filepath) if filepath else DATA_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    with open(target, "w", encoding="utf-8") as f:
        json.dump([todo.to_dict() for todo in todos], f, indent=2)


