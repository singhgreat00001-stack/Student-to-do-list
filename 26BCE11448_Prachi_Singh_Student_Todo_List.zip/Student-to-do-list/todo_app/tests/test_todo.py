from datetime import date, timedelta
from todo_app.models import Todo
from todo_app.validators import validate_todo, validate_status
from todo_app.search import filter_todos
from todo_app.analytics import get_statistics
from todo_app.task_manager import TodoManager
from todo_app.storage import load_todos, save_todos

def sample_tasks():
    yesterday = (date.today() - timedelta(days=1)).isoformat()
    return [
        Todo(1, "Finish Python", "Loops assignment", "2099-01-01", "High", "Study", "Pending"),
        Todo(2, "Read book", "Chapter 3", "2099-01-02", "Low", "Personal", "Completed"),
        Todo(3, "Project report", "Write introduction", "2099-01-03", "Medium", "Project", "Pending"),
        Todo(4, "Overdue Assignment", "Submit on portal", yesterday, "High", "Study", "Pending"),
    ]

def test_validation():
    # Valid input
    assert validate_todo("Task", "2099-01-01", "High")[0]
    assert validate_todo("  Task with spaces  ", " 2099-01-01 ", " Medium ")[0]
    
    # Invalid inputs
    assert not validate_todo("", "2099-01-01", "High")[0]
    assert not validate_todo("   ", "2099-01-01", "High")[0]
    assert not validate_todo("Task", "", "High")[0]
    assert not validate_todo("Task", "wrong-date", "High")[0]
    assert not validate_todo("Task", "2099/01/01", "High")[0]
    assert not validate_todo("Task", "2099-01-01", "Urgent")[0]

def test_validate_status():
    assert validate_status("Pending")
    assert validate_status("Completed")
    assert not validate_status("InProgress")

def test_search_and_filters():
    tasks = sample_tasks()
    
    # Search by title keyword
    results = filter_todos(tasks, keyword="python")
    assert len(results) == 1
    assert results[0].id == 1

    # Search by category keyword
    results = filter_todos(tasks, keyword="study")
    assert len(results) == 2

    # Search by description
    results = filter_todos(tasks, keyword="chapter")
    assert len(results) == 1

    # Filter by status
    results = filter_todos(tasks, status="Completed")
    assert len(results) == 1
    assert results[0].id == 2

    # Filter by priority
    results = filter_todos(tasks, priority="High")
    assert len(results) == 2

    # Combined filter
    results = filter_todos(tasks, keyword="Study", priority="High", status="Pending")
    assert len(results) == 2

def test_statistics():
    stats = get_statistics(sample_tasks())
    assert stats["total"] == 4
    assert stats["completed"] == 1
    assert stats["pending"] == 3
    assert stats["overdue"] == 1
    assert stats["high_priority"] == 2
    assert stats["completion_rate"] == 25.0

def test_task_manager_crud(tmp_path):
    temp_json = tmp_path / "test_todos.json"
    manager = TodoManager(storage_file=temp_json)

    # Add task
    t1 = manager.add("Test Task 1", "Desc 1", "2099-05-01", "High", "Academic")
    assert t1.id == 1
    assert len(manager.all()) == 1

    # Add second task
    t2 = manager.add("Test Task 2", "Desc 2", "2099-05-02", "Low", "Personal")
    assert t2.id == 2
    assert len(manager.all()) == 2

    # Complete task
    assert manager.complete(1)
    assert manager.get(1).status == "Completed"

    # Toggle status back to Pending
    assert manager.toggle_status(1) == "Pending"
    assert manager.get(1).status == "Pending"

    # Update task
    assert manager.update(1, "Updated Task 1", "Updated Desc", "2099-05-10", "Medium", "Study", "Pending")
    updated = manager.get(1)
    assert updated.title == "Updated Task 1"
    assert updated.priority == "Medium"

    # Delete task
    assert manager.delete(2)
    assert len(manager.all()) == 1
    assert manager.get(2) is None

def test_storage_robustness(tmp_path):
    corrupt_file = tmp_path / "corrupt.json"
    corrupt_file.write_text("{ broken json content", encoding="utf-8")
    assert load_todos(corrupt_file) == []

    non_list_file = tmp_path / "non_list.json"
    non_list_file.write_text('{"key": "value"}', encoding="utf-8")
    assert load_todos(non_list_file) == []
