import sys
import os
import json
import time
import struct
import ctypes
import ctypes.wintypes
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

# Ensure imports from current directory work
sys.path.insert(0, str(Path(__file__).resolve().parent))

import tkinter as tk
from tkinter import ttk
from todo_app.models import Todo
from todo_app.task_manager import TodoManager
from todo_app.ui import App

SCREENSHOTS_DIR = Path(__file__).resolve().parent / "Screenshots"
SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)

DATA_FILE = Path(__file__).resolve().parent / "data" / "todos.json"

INITIAL_TASKS = [
    {
        "id": 1,
        "title": "C++",
        "description": "Study",
        "due_date": "2026-09-25",
        "priority": "High",
        "category": "Coding",
        "status": "Completed"
    },
    {
        "id": 2,
        "title": "Data Structures Lab Report",
        "description": "Implement AVL Trees and write analysis section for Lab 4",
        "due_date": "2026-09-24",
        "priority": "High",
        "category": "Academic",
        "status": "Pending"
    },
    {
        "id": 3,
        "title": "DBMS Quiz Preparation",
        "description": "Review ER modeling, relational algebra, and SQL normalization",
        "due_date": "2026-09-28",
        "priority": "Medium",
        "category": "Study",
        "status": "Pending"
    },
    {
        "id": 4,
        "title": "Hackathon Team Registration",
        "description": "Submit team roster and problem statement preference on portal",
        "due_date": "2026-09-30",
        "priority": "Low",
        "category": "Extracurricular",
        "status": "Pending"
    }
]

def capture_window_hwnd(hwnd):
    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    root_hwnd = user32.GetAncestor(hwnd, 2)
    rect = ctypes.wintypes.RECT()
    user32.GetWindowRect(root_hwnd, ctypes.byref(rect))
    w = rect.right - rect.left
    h = rect.bottom - rect.top

    hdc_screen = user32.GetWindowDC(root_hwnd)
    hdc_mem = gdi32.CreateCompatibleDC(hdc_screen)
    hbmp = gdi32.CreateCompatibleBitmap(hdc_screen, w, h)
    gdi32.SelectObject(hdc_mem, hbmp)
    user32.PrintWindow(root_hwnd, hdc_mem, 2)

    bmpinfo = ctypes.create_string_buffer(40)
    struct.pack_into('<IiiHHIIIIII', bmpinfo, 0, 40, w, -h, 1, 32, 0, w * h * 4, 0, 0, 0, 0)
    buf = ctypes.create_string_buffer(w * h * 4)
    gdi32.GetDIBits(hdc_mem, hbmp, 0, h, buf, bmpinfo, 0)

    im = Image.frombuffer('RGBA', (w, h), buf, 'raw', 'BGRA', 0, 1)
    im = im.convert('RGB')
    gdi32.DeleteObject(hbmp)
    gdi32.DeleteDC(hdc_mem)
    user32.ReleaseDC(root_hwnd, hdc_screen)
    return im

def capture_app(app, filename):
    app.update_idletasks()
    app.update()
    time.sleep(0.05)
    img = capture_window_hwnd(app.winfo_id())
    out_path = SCREENSHOTS_DIR / filename
    img.save(out_path)
    print(f"Saved: {out_path} ({img.size[0]}x{img.size[1]})")

def capture_app_with_modal(app, filename, title, message, icon_type="error", buttons=("OK",)):
    # Render simulated modal on top of app
    app.update_idletasks()
    app.update()
    main_img = capture_window_hwnd(app.winfo_id())

    # Build modal window
    modal = tk.Toplevel(app)
    modal.title(title)
    modal.geometry("380x150")
    modal.resizable(False, False)
    modal.transient(app)
    modal.grab_set()

    frame = ttk.Frame(modal, padding=15)
    frame.pack(fill="both", expand=True)

    icon_char = "X" if icon_type == "error" else ("!" if icon_type == "warning" else "?")
    icon_bg = "#d9534f" if icon_type == "error" else ("#f0ad4e" if icon_type == "warning" else "#0275d8")
    
    icon_lbl = tk.Label(frame, text=icon_char, font=("Segoe UI", 16, "bold"), fg="white", bg=icon_bg, width=3, height=1)
    icon_lbl.grid(row=0, column=0, padx=(0, 15), pady=(10, 10))

    msg_lbl = ttk.Label(frame, text=message, font=("Segoe UI", 10), wraplength=260)
    msg_lbl.grid(row=0, column=1, sticky="w", pady=(10, 10))

    btn_frame = ttk.Frame(frame)
    btn_frame.grid(row=1, column=0, columnspan=2, pady=(10, 0), sticky="e")
    for btn_text in buttons:
        ttk.Button(btn_frame, text=btn_text, width=10, command=modal.destroy).pack(side="left", padx=5)

    modal.update_idletasks()
    modal.update()
    time.sleep(0.05)

    modal_img = capture_window_hwnd(modal.winfo_id())
    
    # Overlay centered
    mw, mh = main_img.size
    dw, dh = modal_img.size
    x = max(0, (mw - dw) // 2)
    y = max(0, (mh - dh) // 2)
    
    # Shadow
    overlay = Image.new("RGBA", main_img.size, (0, 0, 0, 50))
    main_img = main_img.convert("RGBA")
    composite = Image.alpha_composite(main_img, overlay)
    composite.paste(modal_img, (x, y))
    composite = composite.convert("RGB")
    
    out_path = SCREENSHOTS_DIR / filename
    composite.save(out_path)
    print(f"Saved modal: {out_path}")
    modal.destroy()
    app.update()

def generate_pytest_screenshot():
    import subprocess
    cmd = [sys.executable, "-m", "pytest", "todo_app/tests", "-v"]
    res = subprocess.run(cmd, capture_output=True, text=True)
    output_text = res.stdout
    
    # Render terminal-style graphic for test results
    lines = output_text.strip().split("\n")
    w = 950
    h = 40 + len(lines) * 24
    img = Image.new("RGB", (w, h), color="#1e1e1e")
    draw = ImageDraw.Draw(img)
    
    # Window header bar
    draw.rectangle([0, 0, w, 32], fill="#2d2d2d")
    draw.text((15, 7), "Command Prompt - pytest todo_app/tests -v", fill="#cccccc")
    draw.ellipse([w-70, 10, w-60, 20], fill="#ff5f56")
    draw.ellipse([w-50, 10, w-40, 20], fill="#ffbd2e")
    draw.ellipse([w-30, 10, w-20, 20], fill="#27c93f")
    
    y = 42
    for line in lines:
        color = "#cccccc"
        if "PASSED" in line or "passed in" in line:
            color = "#4ec9b0"
        elif "test session starts" in line or "rootdir:" in line:
            color = "#9cdcfe"
        elif "collected" in line:
            color = "#dcdcaa"
        draw.text((15, y), line, fill=color)
        y += 24
        
    out_path = SCREENSHOTS_DIR / "13_pytest_test_results.png"
    img.save(out_path)
    print(f"Saved test run screenshot: {out_path}")

def run_all():
    # 1. Reset initial JSON data
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(INITIAL_TASKS, f, indent=2)

    app = App()
    app.geometry("1050x680")
    app.update()

    # 1_main_interface.png
    capture_app(app, "1_main_interface.png")

    # 2_add_task_form.png
    app.title_entry.delete(0, tk.END)
    app.title_entry.insert(0, "Operating Systems Assignment")
    app.desc_entry.delete(0, tk.END)
    app.desc_entry.insert(0, "CPU Scheduling algorithms simulation")
    app.date_entry.delete(0, tk.END)
    app.date_entry.insert(0, "2026-10-02")
    app.priority.set("High")
    app.category_entry.delete(0, tk.END)
    app.category_entry.insert(0, "Core CSE")
    capture_app(app, "2_add_task_form.png")

    # 3_task_added.png
    app.add_task()
    capture_app(app, "3_task_added.png")

    # 4_search_filter.png
    app.search_entry.delete(0, tk.END)
    app.search_entry.insert(0, "Lab")
    app.refresh()
    capture_app(app, "4_search_filter.png")

    # Clear search
    app.search_entry.delete(0, tk.END)
    app.refresh()

    # 5_priority_filter.png
    app.priority_filter.set("High")
    app.refresh()
    capture_app(app, "5_priority_filter.png")

    # 6_status_filter_pending.png
    app.priority_filter.set("All")
    app.status_filter.set("Pending")
    app.refresh()
    capture_app(app, "6_status_filter_pending.png")

    # 7_status_filter_completed.png
    app.status_filter.set("Completed")
    app.refresh()
    capture_app(app, "7_status_filter_completed.png")

    # Reset filters
    app.status_filter.set("All")
    app.priority_filter.set("All")
    app.refresh()

    # 8_completed_task.png (Mark Task 2 Completed)
    for child in app.tree.get_children():
        if app.tree.item(child)["values"][0] == 2:
            app.tree.selection_set(child)
            break
    app.complete()
    capture_app(app, "8_completed_task.png")

    # 9_validation_error_date.png
    capture_app_with_modal(
        app,
        "9_validation_error_date.png",
        title="Validation Error",
        message="Due date must use YYYY-MM-DD format.",
        icon_type="error",
        buttons=("OK",)
    )

    # 10_validation_error_title.png
    capture_app_with_modal(
        app,
        "10_validation_error_title.png",
        title="Validation Error",
        message="Task title is required.",
        icon_type="error",
        buttons=("OK",)
    )

    # 11_selection_warning.png
    capture_app_with_modal(
        app,
        "11_selection_warning.png",
        title="Selection",
        message="Please select a task.",
        icon_type="warning",
        buttons=("OK",)
    )

    # 12_delete_confirmation.png
    capture_app_with_modal(
        app,
        "12_delete_confirmation.png",
        title="Confirm",
        message="Delete this task?",
        icon_type="question",
        buttons=("Yes", "No")
    )

    app.destroy()

    # 13_pytest_test_results.png
    generate_pytest_screenshot()

    # Also make sure the original 5 filenames match the report references:
    # 1_main_interface.png, 2_add_task_form.png, 3_search_filter.png, 4_priority_filter.png, 5_completed_task.png
    # Let's copy 8_completed_task.png to 5_completed_task.png and 4_search_filter.png to 3_search_filter.png etc if needed
    # so that the report's exact figures 1 to 5 are also updated!
    import shutil
    shutil.copy(SCREENSHOTS_DIR / "4_search_filter.png", SCREENSHOTS_DIR / "3_search_filter.png")
    shutil.copy(SCREENSHOTS_DIR / "5_priority_filter.png", SCREENSHOTS_DIR / "4_priority_filter.png")
    shutil.copy(SCREENSHOTS_DIR / "8_completed_task.png", SCREENSHOTS_DIR / "5_completed_task.png")

if __name__ == "__main__":
    run_all()
